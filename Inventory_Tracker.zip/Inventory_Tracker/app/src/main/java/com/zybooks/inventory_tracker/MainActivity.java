package com.zybooks.inventory_tracker;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

//define variables
    EditText username;
    EditText password;
    EditText retypePassword;
    dataBaseHelper DB;
    Button SignUp;
    Button SignIn;

//method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /* initialized variables */
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        retypePassword = (EditText) findViewById(R.id.retypePassword);
        SignIn  =  (Button) findViewById(R.id.SignIn);
        SignUp = (Button) findViewById(R.id.SignUp);
        DB = new dataBaseHelper(this);

//method for sign up on click listener
        SignUp.setOnClickListener(new View.OnClickListener() {

            //methods
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = retypePassword.getText().toString();

                //add conditions and toast messages for Sign up
                //Give access to HomeActivity if credentials are valid else toast message to display

                if(user.equals("")||pass.equals("")||repass.equals(""))
                    Toast.makeText(MainActivity.this, "Enter all Fields", Toast.LENGTH_SHORT).show();
                else{
                    if(pass.equals(repass)){
                        Boolean checkUser = DB.checkUsername(user);
                        if(checkUser==false){
                            Boolean insert = DB.insertData(user, pass);
                            if(insert ==true){
                                Toast.makeText(MainActivity.this, "Created account successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                                startActivity(intent);

                            }else{
                                Toast.makeText(MainActivity.this, "Registration Fail", Toast.LENGTH_SHORT).show();

                            }
                        }
                        else{
                            Toast.makeText(MainActivity.this, "User already exist please sign in", Toast.LENGTH_SHORT).show();

                        }
                    }else{
                        Toast.makeText(MainActivity.this, "Password is Incorrect", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        // create sign in method listener
        //Give access to login Activity if existing user

        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);

            }
        });

    }
}

