package com.zybooks.inventory_tracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
// class extends SQLiteOpenHelper
public class dataBaseHelper extends SQLiteOpenHelper {

    public static final String dBName ="loginItems.db";
//constructor
    public dataBaseHelper( Context context) {
//name SQData
        super(context, "LoginItems.db", null, 1);

    }
//methods onCreate, onUpgrade, insertData, check for username, check for password
    @Override
    public void onCreate(SQLiteDatabase db) {
        //table create for loginItems data
        db.execSQL("create Table users(username TEXT primary key, password TEXT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop Table if exists users");

    }

    public Boolean insertData(String username, String password){

        // data values to be added
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = db.insert("users", null, contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }
    public boolean checkUsername(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from users where username = ?", new String [] {username});
        if (cursor.getCount()>0)
            return true;
        else
            return false;

    }

    public Boolean checkUsernamePassword(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from users where username =? and password = ?", new String[] {username,password});
        if (cursor.getCount()>0)
            return true;

        else
            return false;
    }

}

