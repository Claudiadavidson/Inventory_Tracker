package com.zybooks.inventory_tracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;


public class HomeActivity extends AppCompatActivity {

//define variables
    GridLayout items;
    ImageView apple;
    ImageView orange;
    ImageView zucchini;
    ImageView cabbage;
    ImageView lemon;
    ImageView jalapeno;
    dataBaseHelper DB;
    Button notification;

//on create method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

//initialize variables
        items = (GridLayout) findViewById(R.id.items);
        apple = (ImageView) findViewById(R.id.apple);
        orange = (ImageView) findViewById(R.id.orange);
        zucchini = (ImageView) findViewById(R.id.zucchini);
        cabbage = (ImageView) findViewById(R.id.cabbage);
        lemon = (ImageView) findViewById(R.id.lemon);
        jalapeno = (ImageView) findViewById(R.id.jalapeno);
        notification = (Button) findViewById(R.id.notification);
        DB = new dataBaseHelper(this);

//create on click listeners apple, orange, zucchini, lemon, notification

        apple.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //get context
                Intent intent = new Intent(getApplicationContext(), orangeActivity.class);
                startActivity(intent);

            }
        });
        orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), orangeActivity.class);
                startActivity(intent);


            }
        });
        zucchini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), orangeActivity.class);
                startActivity(intent);

            }
        });
        cabbage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), orangeActivity.class);
                startActivity(intent);

            }
        });
        lemon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), orangeActivity.class);
                startActivity(intent);

            }
        });
        jalapeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), orangeActivity.class);
                startActivity(intent);
            }
        });
        //method for notification
        notification.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View v) {
//notification builder
                NotificationCompat.Builder builder = new NotificationCompat.Builder(HomeActivity.this, "Notification check");
                builder.setContentTitle("Inventory Items");
                builder.setContentText("Hello Inventory some inventory is Low");
                builder.setSmallIcon(R.drawable.ic_launcher_background);
                builder.setAutoCancel(true);

                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(HomeActivity.this);
                managerCompat.notify(1,builder.build());
            }
        });

    }
}