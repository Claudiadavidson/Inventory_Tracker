package com.zybooks.inventory_tracker;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    /* define variables */
    Button SignIn;
    EditText username;
    EditText password;

    dataBaseHelper DB;

//method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Initialize
        password = (EditText) findViewById(R.id.password1);
        username = (EditText) findViewById(R.id.username1);
        SignIn = (Button) findViewById(R.id.SignIn1);
        DB = new dataBaseHelper(this);

        //set sign in button to on click listener

      SignIn.setOnClickListener(new View.OnClickListener() {

          //create method for listener

          @Override
          public void onClick(View v) {
            //string username and password from sign in page
              String user = username.getText().toString();
              String pass = password.getText().toString();

              //add conditions and toast messages for Sign In
              //Give access to HomeActivity if credentials are valid else toast message to display
              if(user.equals("")||pass.equals(""))
                  Toast.makeText(LoginActivity.this, "Enter all Fields", Toast.LENGTH_SHORT).show();
              else{
                  Boolean checkUserPass= DB. checkUsernamePassword(user, pass);
                  if(checkUserPass==true){
                      Toast.makeText(LoginActivity.this, "Sign in successfully", Toast.LENGTH_SHORT).show();
                      Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                      startActivity(intent);
                  }else{
                       Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                  }
              }
          }
      });

    }
}
